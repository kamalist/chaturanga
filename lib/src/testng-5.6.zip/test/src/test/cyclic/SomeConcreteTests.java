package test.cyclic;

import org.testng.annotations.Test;

public class SomeConcreteTests extends AbstractGenericTests {

    @Test(groups="integration")
    public void testSomethingElse() {
        //...
    }

 }