package com.beust.testng;

/**
 * For backward compatibility.
 * 
 * Created on Jun 18, 2005
 * @author <a href="mailto:cedric@beust.com">Cedric Beust</a>
 * @deprecated Use org.testng.TestNG
 */
public class TestNG extends org.testng.TestNG {
  
}